typedef char *key;

int fhash (int, key); //funzione di hashing
